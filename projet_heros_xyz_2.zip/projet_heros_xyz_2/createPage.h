#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef CREATEPAGE_H
#define CREATEPAGE_H

void generer_la_page_index();
void generate_sect000_html();
void generate_style_css();
void generate_dom_js();
void generate_inventory_page();

#endif
