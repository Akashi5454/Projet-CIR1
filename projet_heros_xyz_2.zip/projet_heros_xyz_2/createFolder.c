#include "createFolder.h"

void creer_dossier_selon_os(void) {
    int choix;
    const char *dossiers[] = {"ressources", "export"};

    printf("Quel est votre système d'exploitation ?\n");
    printf("1. Linux\n");
    printf("2. macOS\n");
    printf("Entrez le numéro correspondant : ");
    scanf("%d", &choix);

    switch (choix) {
        case 1:
        case 2:
            printf("Création des dossiers sous Linux/macOS...\n");
            for (int i = 0; i < 2; i++) {
                char cmd_unix[150];
                sprintf(cmd_unix, "mkdir -p %s", dossiers[i]);
                system(cmd_unix);

                char fullpath[PATH_MAX];
                if (realpath(dossiers[i], fullpath) != NULL) {
                    printf("Chemin complet du dossier \"%s\" créé : %s\n", dossiers[i], fullpath);
                } else {
                    perror("Erreur lors de la récupération du chemin complet");
                }
            }
            break;

        default:
            printf("Choix invalide.\n");
            return;
    }

    printf("Dossiers \"ressources\" et \"export\" créés avec succès (si aucun message d'erreur n'est apparu).\n");
}

void deplacer_fichier_vers_ressources() {
    const char *src = "02fotw.data";
    const char *dest = "ressources/02fotw.data";

    if (rename(src, dest) == 0) {
        printf("Fichier déplacé avec succès de '%s' vers '%s'.\n", src, dest);
    } else {
        perror("Erreur lors du déplacement du fichier");
    }
}
