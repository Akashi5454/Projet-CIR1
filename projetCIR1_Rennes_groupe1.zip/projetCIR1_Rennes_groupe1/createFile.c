#include "createFile.h"

// Fonction principale qui lit un fichier source HTML contenant plusieurs <section>
// et génère un fichier HTML séparé pour chaque section.
void generate_html_sections(const char* filepath) {
    FILE* file = fopen(filepath, "r");
    if (file == NULL) {
        perror("Erreur d'ouverture du fichier");
        fprintf(stderr, "Chemin essayé : %s\n", filepath);
        exit(EXIT_FAILURE);
    }

    char line[LINE_SIZE];
    FILE* current_section = NULL;
    int section_count = 0;

    // Lecture ligne par ligne du fichier source
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0;  // Supprimer le saut de ligne final

        if (strncmp(line, "<section>", 9) == 0) {
            // Fin de la section précédente s'il y en avait une
            if (current_section != NULL)
                end_section(current_section);

            section_count++;
            if (section_count > 350) {
                fprintf(stderr, "Erreur : plus de 350 sections détectées.\n");
                fclose(file);
                exit(EXIT_FAILURE);
            }

            // Démarre une nouvelle section
            current_section = start_section(section_count);

        } else if (strncmp(line, "</section>", 10) == 0) {
            // Fin de la section courante
            end_section(current_section);
            current_section = NULL;

        } else if (current_section != NULL) {
            // Remplacement des balises <a> et idref="action", puis écriture dans le fichier
            const char* tmp1 = replace_action_chart(line);
            const char* tmp2 = replace_links_only(tmp1);
            fprintf(current_section, "<p>%s</p>\n", tmp2);
        }
    }

    // Ferme la dernière section si elle n'a pas été fermée
    if (current_section != NULL)
        end_section(current_section);

    fclose(file);
}

// Fonction qui remplace toutes les balises <a>...</a> contenant un numéro
// par un lien HTML vers une section correspondante (sectX.html)
char* replace_links_only(const char* input) {
    static char output[2048];
    output[0] = '\0';

    const char* p = input;

    while (*p) {
        const char* start = strstr(p, "<a>");
        if (!start) {
            strcat(output, p);
            break;
        }

        // Copier tout le texte avant <a>
        strncat(output, p, start - p);

        const char* end = strstr(start, "</a>");
        if (!end) {
            strcat(output, start);
            break;
        }

        // Extraire le contenu entre <a> et </a>
        char inner[256];
        int len = end - (start + 3);
        strncpy(inner, start + 3, len);
        inner[len] = '\0';

        // Recherche d'un nombre dans le contenu pour faire le lien
        int number = 0;
        for (int i = 0; inner[i]; i++) {
            if (inner[i] >= '0' && inner[i] <= '9') {
                number = atoi(&inner[i]);
                break;
            }
        }

        char link[512];
        if (number > 0)
            sprintf(link, "<a href=\"sect%d.html\">%s</a>", number, inner);
        else
            sprintf(link, "<a>%s</a>", inner);

        strcat(output, link);
        p = end + 4; // Passe après </a>
    }

    return output;
}

// Fonction qui détecte une balise <a idref="action">Action Chart</a>
// et la remplace par un lien vers la page "inventory.html" dans un nouvel onglet
char* replace_action_chart(const char* input) {
    static char output[2048];
    output[0] = '\0';

    const char* p = input;

    while (*p) {
        const char* start = strstr(p, "<a idref=\"action\">");
        if (!start) {
            strcat(output, p);
            break;
        }

        // Copier le texte avant la balise
        strncat(output, p, start - p);

        const char* end = strstr(start, "</a>");
        if (!end) {
            strcat(output, start);
            break;
        }

        // Extraire le contenu de la balise
        char inner[256];
        int len = end - (start + strlen("<a idref=\"action\">"));
        strncpy(inner, start + strlen("<a idref=\"action\">"), len);
        inner[len] = '\0';

        // Vérifie si c'est "Action Chart"
        if (strcmp(inner, "Action Chart") == 0) {
            strcat(output, "<a href=\"inventory.html\" target=\"_blank\">Action Chart</a>");
        } else {
            // Sinon garde la balise originale
            strncat(output, start, end + 4 - start);
        }

        p = end + 4;
    }

    return output;
}

// Fonction qui démarre une nouvelle section HTML (fichier export/sectX.html)
FILE* start_section(int section_number) {
    char filename[256];
    sprintf(filename, "export/sect%d.html", section_number);

    FILE* f = fopen(filename, "w");
    if (!f) {
        fprintf(stderr, "Impossible de créer le fichier <%s>\n", filename);
        exit(EXIT_FAILURE);
    }

    // Écriture du début du fichier HTML (head, style, script, etc.)
    fprintf(f,
            "<!DOCTYPE html>\n"
            "<html>\n"
            "<head>\n"
            "  <meta charset=\"UTF-8\">\n"
            "  <title>Section %d</title>\n"
            "  <link href=\"../ressources//style.css\" rel=\"stylesheet\"/>\n"
            "  <script>\n"
            "    document.addEventListener('DOMContentLoaded', () => {\n"
            "      document.body.addEventListener('click', (e) => {\n"
            "        const target = e.target;\n"
            "        if (!target) return;\n"
            "\n"
            "        let label = target.dataset.label || target.textContent.trim();\n"
            "\n"
            "        label = label.replace(/^(Turn to|Aller à)\\s*/i, '');\n"
            "\n"
            "        label = label.substring(0, 50);\n"
            "\n"
            "        window.parent.postMessage({ type: \"sectionClick\", label: label }, \"*\");\n"
            "      });\n"
            "    });\n"
            "  </script>\n"
            "  <style>\n"
            "    body {\n"
            "      background-color: white;\n"
            "      color: black;\n"
            "      margin:10px;\n"
            "    }\n"
            "  </style>\n"
            "</head>\n"
            "<body>\n"
            "<h1>Section %d</h1>\n",
            section_number, section_number
    );

    return f;
}

// Fonction qui termine proprement une section HTML (ferme les balises)
void end_section(FILE* file) {
    if (file) {
        fprintf(file, "<script src=\"/ressources/dom.js\"></script>\n");
        fprintf(file, "</body>\n</html>\n");
        fclose(file);
    }
}
