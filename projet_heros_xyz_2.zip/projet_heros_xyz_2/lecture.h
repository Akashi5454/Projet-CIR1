//
// Created by Noé Gavard on 12/06/2025.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef LECTURE_H
#define LECTURE_H

#define LINE_SIZE 2000

void startSect(char* sect_name);

#endif //LECTURE_H
