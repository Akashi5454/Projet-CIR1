#include "createFile.h"




void generate_html_sections(const char* filepath) {
    FILE* file = fopen(filepath, "r");
    if (file == NULL) {
        perror("Erreur d'ouverture du fichier");
        fprintf(stderr, "Chemin essayé : %s\n", filepath);
        exit(EXIT_FAILURE);
    }

    char line[LINE_SIZE];
    FILE* current_section = NULL;
    int section_count = 0;

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0;  // Supprimer le saut de ligne

        if (strncmp(line, "<section>", 9) == 0) {
            if (current_section != NULL)
                end_section(current_section);

            section_count++;
            if (section_count > 350) {
                fprintf(stderr, "Erreur : plus de 350 sections détectées.\n");
                fclose(file);
                exit(EXIT_FAILURE);
            }

            current_section = start_section(section_count);

        } else if (strncmp(line, "</section>", 10) == 0) {
            end_section(current_section);
            current_section = NULL;

        } else if (current_section != NULL) {
            fprintf(current_section, "<p>%s</p>\n", replace_links_only(line));
        }
    }

    if (current_section != NULL)
        end_section(current_section);

    fclose(file);
}




char* replace_links_only(const char* input) {
    static char output[2048];
    output[0] = '\0';

    const char* p = input;

    while (*p) {
        const char* start = strstr(p, "<a>");
        if (!start) {
            strcat(output, p);
            break;
        }

        // Copier tout ce qu'il y a avant <a>
        strncat(output, p, start - p);

        const char* end = strstr(start, "</a>");
        if (!end) {
            strcat(output, start);
            break;
        }

        // Contenu entre <a> et </a>
        char inner[256];
        int len = end - (start + 3);
        strncpy(inner, start + 3, len);
        inner[len] = '\0';

        // Cherche le premier nombre dans inner
        int number = 0;
        for (int i = 0; inner[i]; i++) {
            if (inner[i] >= '0' && inner[i] <= '9') {
                number = atoi(&inner[i]);
                break;
            }
        }

        char link[512];
        if (number > 0)
            sprintf(link, "<a href=\"sect%d.html\">%s</a>", number, inner);
        else
            sprintf(link, "<a>%s</a>", inner);

        strcat(output, link);
        p = end + 4; // après </a>
    }

    return output;
}

FILE* start_section(int section_number) {
    char filename[256];
    sprintf(filename, "export/sect%d.html", section_number);
    
    FILE* f = fopen(filename, "w");
    if (!f) {
        fprintf(stderr, "Impossible de créer le fichier <%s>\n", filename);
        exit(EXIT_FAILURE);
    }
    
    fprintf(f,
            "<!DOCTYPE html>\n"
            "<html>\n"
            "<head>\n"
            "  <meta charset=\"UTF-8\">\n"
            "  <title>Section %d</title>\n"
            "  <link href=\"../ressources//style.css\" rel=\"stylesheet\"/>\n"
            "  <script>\n"
            "    document.addEventListener('DOMContentLoaded', () => {\n"
            "      document.body.addEventListener('click', (e) => {\n"
            "        const target = e.target;\n"
            "        if (!target) return;\n"
            "\n"
            "        let label = target.dataset.label || target.textContent.trim();\n"
            "\n"
            "        label = label.replace(/^(Turn to|Aller à)\\s*/i, '');\n"
            "\n"
            "        label = label.substring(0, 50);\n"
            "\n"
            "        window.parent.postMessage({ type: \"sectionClick\", label: label }, \"*\");\n"
            "      });\n"
            "    });\n"
            "  </script>\n"
            "  <style>\n"
            "    body {\n"
            "      background-color: white; /* par exemple gris foncé */\n"
            "      color: black;\n"
            "    }\n"
            "  </style>\n"
            "</head>\n"
            "<body>\n"
            "<h1>Section %d</h1>\n",
            section_number, section_number
            );
    
    return f;
}

void end_section(FILE* file) {
    if (file) {
        fprintf(file, "</body>\n</html>\n");
        fclose(file);
    }
}












void generer_index() {
    FILE *fichier = fopen("export/index.html", "w");
    if (fichier == NULL) {
        perror("Erreur lors de la création du fichier HTML");
        return;
    }

    fprintf(fichier,
        "<!DOCTYPE html>\n"
        "<html lang=\"fr\">\n"
        "<head>\n"
        "  <meta charset=\"UTF-8\">\n"
        "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
        "  <title>Loup Solitaire - Le Début de l'Aventure</title>\n"
        "  <style>\n"
        "    body {\n"
        "      font-family: 'Georgia', serif;\n"
        "      background-color: #f4f4e9;\n"
        "      color: #333;\n"
        "      margin: 0;\n"
        "      display: flex;\n"
        "      flex-direction: column;\n"
        "      justify-content: center;\n"
        "      align-items: center;\n"
        "      min-height: 100vh;\n"
        "      padding: 20px;\n"
        "      box-sizing: border-box;\n"
        "    }\n"
        "    h1 {\n"
        "      color: #2a2a2a;\n"
        "      font-size: 3.5em;\n"
        "      text-align: center;\n"
        "      margin-bottom: 30px;\n"
        "      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);\n"
        "      letter-spacing: 2px;\n"
        "      text-transform: uppercase;\n"
        "    }\n"
        "    img {\n"
        "      max-width: 90%%;\n"
        "      height: auto;\n"
        "      border: 5px solid #a0522d;\n"
        "      border-radius: 8px;\n"
        "      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);\n"
        "      margin-bottom: 40px;\n"
        "      transition: transform 0.3s ease-in-out;\n"
        "    }\n"
        "    img:hover {\n"
        "      transform: scale(1.02);\n"
        "    }\n"
        "    a {\n"
        "      display: inline-block;\n"
        "      background-color: #8b4513;\n"
        "      color: #ffffff;\n"
        "      padding: 15px 30px;\n"
        "      text-decoration: none;\n"
        "      border-radius: 50px;\n"
        "      font-size: 1.5em;\n"
        "      font-weight: bold;\n"
        "      transition: background-color 0.3s ease, transform 0.3s ease;\n"
        "      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n"
        "      letter-spacing: 1px;\n"
        "      text-transform: uppercase;\n"
        "    }\n"
        "    a:hover {\n"
        "      background-color: #a0522d;\n"
        "      transform: translateY(-3px);\n"
        "      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);\n"
        "    }\n"
        "    a:active {\n"
        "      transform: translateY(0);\n"
        "      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n"
        "    }\n"
        "    @media (max-width: 768px) {\n"
        "      h1 { font-size: 2.5em; }\n"
        "      a { font-size: 1.2em; padding: 12px 25px; }\n"
        "    }\n"
        "    @media (max-width: 480px) {\n"
        "      h1 { font-size: 2em; }\n"
        "      img { border-width: 3px; }\n"
        "      a { font-size: 1em; padding: 10px 20px; }\n"
        "    }\n"
        "  </style>\n"
        "</head>\n"
        "<body>\n"
        "  <h1>Loup Solitaire</h1>\n"
        "  <img src=\"https://media.pocketgamer.fr/images/news/2011/08/Lone-Wolf.png\" alt=\"Illustration Loup Solitaire\" />\n"
        "  <a href=\"../export/sect000.html\">Commencer l'Aventure</a>\n"
        "</body>\n"
        "</html>\n"
    );

    fclose(fichier);
}

