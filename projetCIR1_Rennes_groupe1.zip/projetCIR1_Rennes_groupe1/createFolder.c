#include "createFolder.h"

// Fonction qui demande à l'utilisateur son système d'exploitation
// et crée les dossiers "ressources" et "export" en conséquence.
void creer_dossier_selon_os(void) {
    int choix;
    const char *dossiers[] = {"ressources", "export"};

    printf("Quel est votre système d'exploitation ?\n");
    printf("1. Linux\n");
    printf("2. macOS\n");
    printf("Entrez le numéro correspondant : ");
    scanf("%d", &choix);

    switch (choix) {
        case 1:
        case 2:
            for (int i = 0; i < 2; i++) {
                // Construction de la commande mkdir pour les systèmes Unix/macOS
                char cmd_unix[150];
                sprintf(cmd_unix, "mkdir -p %s", dossiers[i]);
                system(cmd_unix); // Exécution de la commande de création du dossier

                // Récupération et affichage du chemin absolu du dossier créé
                char fullpath[PATH_MAX];
                if (realpath(dossiers[i], fullpath) != NULL) {
                    printf("Chemin complet du dossier \"%s\" créé : %s\n", dossiers[i], fullpath);
                } else {
                    perror("Erreur lors de la récupération du chemin complet");
                }
            }
            break;

        default:
            printf("Choix invalide.\n");
            return;
    }

    printf("✅ Dossiers \"ressources\" et \"export\" créés avec succès.\n");
}

// Fonction qui déplace automatiquement le fichier 02fotw.data
// dans le dossier "ressources"
void deplacer_fichier_vers_ressources() {
    const char *src = "02fotw.data";                    // Nom du fichier source
    const char *dest = "ressources/02fotw.data";        // Chemin de destination

    if (rename(src, dest) == 0) {
        printf("✅ Fichier déplacé avec succès de '%s' vers '%s'.\n", src, dest);
    } else {
        perror("Erreur lors du déplacement du fichier");
    }
}
