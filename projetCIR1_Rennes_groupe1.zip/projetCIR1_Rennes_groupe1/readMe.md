Pour pouvoir faire marcher le programe il faut premièrement que votre ordinateur marche soit sur une distribution linux ou un mac 
Attention !!! le programme ne marche pas sur windows !

Vous devez ensuite créer un dossier via cette ligne de commande :
mkdir "votre_nom_de_dossier" 

puis vous devez déplacer les fichier suivants à l'intérieur de ce dossier :
- 02fotw.data
- Makefile
- main.c
- createFile.c
- createFile.h
- createFolder.c
- createFolder.h
- createPage.c
- createPage.h
vous pouvez le faire via la commande :
cp chemin/vers/votrefichier.txt votre_nom_de_dossier/
exemple : 
cp 02fow.data dossier/
ou bien vous pouvez glisser/déposer les fichiers dans le dossier
Attention !!! Les fichiers doivent être obligatoirement dans le même dossier pour que le programme fonctionne !!!

vérifier que la commande gcc et que la commande make soient bien installées via les commande :
gcc --version

si gcc n'est pas installé vous verrez : 
command not found: gcc 
dans ce cas la pour l'installer vous devez taper les commandes : 
sudo apt update
puis
sudo apt install build-essential 
ensuite refaite la commande :
gcc --version

ensuite taper la commande (si vous venez d'installer gcc normalement make sera aussi installer et vous devrez juste vous assuré que make soit bien installé via cette commande) :
make --version
si ce n'est pas le cas retapez
sudo apt install build-essential
puis retaper la commande :
make -- version

ensuite vous avez juste à aller dan sle répertoire que vous venez de créer via la commande :
cd chemin/vers/"votre_nom_de_dossier"

ensuite vous devez tapper la commande :
make

si vous avec bien respecter l'arborescence situé au-dessus vous devriez voir ce message après la commande make: 
"votre_nom_de_machine" "votre_nom_de_dossier" % make
gcc -Wall -c createPage.c -o build/./createPage.c.o
gcc -Wall -c createFile.c -o build/./createFile.c.o
gcc -Wall -c createFolder.c -o build/./createFolder.c.o
gcc -Wall -c main.c -o build/./main.c.o
gcc -Wall ./build/./createPage.c.o ./build/./createFile.c.o ./build/./createFolder.c.o ./build/./main.c.o -o tambouille -lm
find: ./export: No such file or directory
make: *** [web] Error 1

le messgae d'erreur indique qu'aucun dossier nommé "export" à été trouvé et donc que aucun fichier.html n'a été supprimé.

ensuite vous devez tapper la commande :
./tambouille
le programme vous demandera ensuite votre système d'exploitation où vous devrez tapper 1 ou 2 avec votre clavier suivant votre système.
si tout c'est bien passer vous devriez voir que 2 dossiers ont été créer le premier nommé export et le deuxième ressources
le dossier export contient les 350 sections différentes de notre livre, une page sect000.html et la page inventory.html
le dossier ressource quand à lui contient le fichier 02fotw.data , dom.js et style.css
vous n'avez plus qu'à double cliquer sur le fichier nommmé :
index.html pour commencer l'aventure.
