//
// Created by Noé Gavard on 12/06/2025.
//

#include "lecture.h"

void startSect(char* sect_name) {
    printf("test\n");
    printf("%s\n", sect_name);
}
