#include "createFile.h"

FILE* start_section(int section_number) {
    char filename[256];
    sprintf(filename, "export/sect%d.html", section_number);  // Nom du fichier basé sur le numéro

    FILE* f = fopen(filename, "w");
    if (!f) {
        fprintf(stderr, "Impossible de créer le fichier <%s>\n", filename);
        exit(EXIT_FAILURE);
    }

    fprintf(f, "<!DOCTYPE html>\n<html>\n<head><title>Section %d</title></head>\n<body>\n", section_number);
    fprintf(f, "<h1>Section %d</h1>\n", section_number);
    return f;
}

void end_section(FILE* file) {
    if (file) {
        fprintf(file, "</body>\n</html>\n");
        fclose(file);
    }
}

void process_choice(char* line, FILE* file) {
    fprintf(file, "<p>%s</p>\n", line);
}
