#include "createFile.h"

int main() {
    
    
    generate_html_sections("./ressources/02fotw.data");
    return 0;
}
