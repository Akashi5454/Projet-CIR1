#include "createFile.h"
#include "createPage.h"
#include "createFolder.h"

int main() {
    
    creer_dossier_selon_os();
    deplacer_fichier_vers_ressources();
    generate_html_sections("./ressources/02fotw.data");
    generate_sect000_html();
    generate_style_css();
    generate_dom_js();
    return 0;
}
