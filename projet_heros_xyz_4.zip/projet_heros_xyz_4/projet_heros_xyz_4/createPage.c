#include "createPage.h"

void generer_la_page_index() {
    char nomFichier[256];
    FILE *f;
    sprintf(nomFichier, "export/index.html");

    f = fopen(nomFichier, "w");

    fprintf(f, "<!DOCTYPE html>\n");
    fprintf(f, "<html lang=\"fr\">\n");
    fprintf(f, "<head>\n");
    fprintf(f, "  <meta charset=\"UTF-8\">\n");
    fprintf(f, "  <title>Page 1</title>\n");
    fprintf(f, "</head>\n");
    fprintf(f, "<body>\n");
    fprintf(f, "<h1>Loup Solitaire</h1>\n");
    fprintf(f, "<img src=\"https://media.pocketgamer.fr/images/news/2011/08/Lone-Wolf.png\" alt=\"Illustration Loup Solitaire\" />\n");
    fprintf(f, "<a href=\"../export/sect000.html\">commencer L'histoire</a>\n");
    fprintf(f, "</body></html>\n");

    fclose(f);
    printf("✅ Fichier créé : %s\n", nomFichier);
}



void generate_sect000_html() {
    FILE *f = fopen("export/sect000.html", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *html =
        "<!DOCTYPE html>\n"
        "<html lang=\"fr\">\n"
        "<head>\n"
        "  <meta charset=\"UTF-8\" />\n"
        "  <title>Aventure interactive</title>\n"
        "  <link rel=\"stylesheet\" href=\"../ressources/style.css\" />\n"  // ../ pour remonter au bon dossier\n
        "</head>\n"
        "<body>\n"
        "  <div class=\"container\">\n"
        "    <!-- Colonne gauche -->\n"
        "    <div class=\"sidebar-left\">\n"
        "      <h2>Random number picker</h2>\n"
        "      <div id=\"number\">?</div>\n"
        "      <button onclick=\"pickNumber()\">Pick Number</button>\n"
        "    </div>\n"
        "\n"
        "    <!-- Zone centrale -->\n"
        "    <div class=\"main\">\n"
        "      <div class=\"main-header\"></div>\n"
        "      <iframe id=\"viewer\" src=\"sect1.html\"></iframe>\n"
        "    </div>\n"
        "\n"
        "    <!-- Colonne droite -->\n"
        "    <div class=\"sidebar-right\">\n"
        "      <h2>History</h2>\n"
        "      <ul id=\"recap-list\"></ul>\n"
        "    </div>\n"
        "  </div>\n"
        "\n"
        "  <script src=\"../ressources/dom.js\"></script>\n"
        "</body>\n"
        "</html>\n";

    fputs(html, f);
    fclose(f);
}

void generate_style_css() {
    FILE *f = fopen("ressources/style.css", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *css =
        "body {\n"
        "  margin: 0;\n"
        "  font-family: Arial, sans-serif;\n"
        "  background-color: #1e1e1e;\n"
        "  color: white;\n"
        "}\n"
        "\n"
        ".container {\n"
        "  display: flex;\n"
        "  height: 100vh;\n"
        "}\n"
        "\n"
        "/* Sidebar gauche */\n"
        ".sidebar-left {\n"
        "  width: 200px;\n"
        "  background-color: #2b2b2b;\n"
        "  padding: 20px;\n"
        "  display: flex;\n"
        "  flex-direction: column;\n"
        "  align-items: center;\n"
        "  gap: 15px;\n"
        "}\n"
        "\n"
        ".sidebar-left h2 {\n"
        "  font-size: 16px;\n"
        "  text-align: center;\n"
        "}\n"
        "\n"
        "/* Cercle jaune */\n"
        "#number {\n"
        "  width: 80px;\n"
        "  height: 80px;\n"
        "  border-radius: 50%;\n"
        "  background-color: wheat;\n"
        "  color: black;\n"
        "  font-size: 24px;\n"
        "  font-weight: bold;\n"
        "  display: flex;\n"
        "  align-items: center;\n"
        "  justify-content: center;\n"
        "}\n"
        "\n"
        "/* Bouton */\n"
        "button {\n"
        "  padding: 10px 15px;\n"
        "  font-size: 14px;\n"
        "  background-color: #444;\n"
        "  color: white;\n"
        "  border: none;\n"
        "  cursor: pointer;\n"
        "}\n"
        "\n"
        "button:hover {\n"
        "  background-color: #666;\n"
        "}\n"
        "\n"
        "/* Zone principale */\n"
        ".main {\n"
        "  flex-grow: 1;\n"
        "  display: flex;\n"
        "  flex-direction: column;\n"
        "  padding: 20px;\n"
        "}\n"
        "\n"
        ".main-header {\n"
        "  font-size: 18px;\n"
        "  margin-bottom: 10px;\n"
        "}\n"
        "\n"
        "iframe {\n"
        "  flex-grow: 1;\n"
        "  width: 100%;\n"
        "  border: none;\n"
        "  background-color: white;\n"
        "}\n"
        "\n"
        "/* Sidebar droite */\n"
        ".sidebar-right {\n"
        "  width: 200px;\n"
        "  background-color: #2b2b2b;\n"
        "  padding: 20px;\n"
        "}\n"
        "\n"
        ".sidebar-right h2 {\n"
        "  font-size: 16px;\n"
        "}\n"
        "\n"
        ".sidebar-right ul {\n"
        "  list-style: none;\n"
        "  padding: 0;\n"
        "  font-size: 14px;\n"
        "}\n"
        "\n"
        "h1 {\n"
        "  text-align: center;\n"
        "}\n"
        "\n"
        "iframe {\n"
        "  background-color: #ffffff; /* ou une autre couleur */\n"
        "}\n";

    fputs(css, f);
    fclose(f);
}

void generate_dom_js() {
    FILE *f = fopen("ressources/dom.js", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *js =
        "// Ajoute une entrée dans la section récap\n"
        "function addToRecap(text) {\n"
        "  const recapList = document.getElementById(\"recap-list\");\n"
        "  const item = document.createElement(\"li\");\n"
        "  item.textContent = text;\n"
        "  recapList.prepend(item);\n"
        "}\n"
        "\n"
        "// Fonction appelée par le bouton\n"
        "function pickNumber() {\n"
        "  const number = Math.floor(Math.random() * 10);\n"
        "  document.getElementById(\"number\").textContent = number;\n"
        "  addToRecap(`Nombre : ${number}`);\n"
        "}\n"
        "\n"
        "// Écoute des messages venant de l’iframe\n"
        "window.addEventListener(\"message\", (event) => {\n"
        "  if (event.data && event.data.type === \"sectionClick\") {\n"
        "    addToRecap(`Section : ${event.data.label}`);\n"
        "  }\n"
        "});\n";

    fputs(js, f);
    fclose(f);
}
