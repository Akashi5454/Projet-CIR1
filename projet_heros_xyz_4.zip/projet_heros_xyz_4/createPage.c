#include "createPage.h"

void generer_la_page_index() {
    char nomFichier[256];
    FILE *f;
    sprintf(nomFichier, "export/index.html");

    f = fopen(nomFichier, "w");

    fprintf(f, "<!DOCTYPE html>\n");
    fprintf(f, "<html lang=\"fr\">\n");
    fprintf(f, "<head>\n");
    fprintf(f, "<meta charset=\"UTF-8\">\n");
    fprintf(f, "<title>Page 1</title>\n");
    fprintf(f, "</head>\n");
    fprintf(f, "<body>\n");
    fprintf(f, "<h1>Loup Solitaire</h1>\n");
    fprintf(f, "<img src=\"https://media.pocketgamer.fr/images/news/2011/08/Lone-Wolf.png\" alt=\"Illustration Loup Solitaire\" />\n");
    fprintf(f, "<a href=\"../export/sect000.html\">commencer L'histoire</a>\n");
    fprintf(f, "</body></html>\n");

    fclose(f);
    printf("✅ Fichier créé : %s\n", nomFichier);
}



void generate_sect000_html() {
    FILE *f = fopen("export/sect000.html", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *html =
        "<!DOCTYPE html>\n"
        "<html lang=\"fr\">\n"
        "<head>\n"
        "  <meta charset=\"UTF-8\" />\n"
        "  <title>Aventure interactive</title>\n"
        "  <link rel=\"stylesheet\" href=\"../ressources/style.css\" />\n"
        "</head>\n"
        "<body>\n"
        "  <div class=\"container\">\n"
        "    \n"
        "    <div class=\"sidebar-left\">\n"
        "      <h2>Random number picker</h2>\n"
        "      <div id=\"number\">?</div>\n"
        "      <button onclick=\"pickNumber()\">Pick Number</button>\n"
        "    </div>\n"
        "\n"
        "    \n"
        "    <div class=\"main\">\n"
        "      <div class=\"main-header\"></div>\n"
        "      <iframe id=\"viewer\" src=\"sect1.html\"></iframe>\n"
        "    </div>\n"
        "\n"
        "    \n"
        "    <div class=\"sidebar-right\">\n"
        "      <h2>History</h2>\n"
        "      <ul id=\"recap-list\"></ul>\n"
        "    </div>\n"
        "  </div>\n"
        "\n"
        "  <script src=\"../ressources/dom.js\"></script>\n"
        "</body>\n"
        "</html>\n";
    fputs(html, f);
    fclose(f);
}

void generate_style_css() {
    FILE *f = fopen("ressources/style.css", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *css =
       "/* Styles généraux pour le corps et le conteneur principal */\n"
        "body {\n"
        "  margin: 10;\n"
        "  font-family: 'Georgia', serif; \n"
        "  background-color: #f4f4e9;\n"
        "  color: #333; \n"
        "  line-height: 1.6; /* Améliore la lisibilité */\n"
        "}\n"
        "\n"
        ".container {\n"
        "  display: flex;\n"
        "  min-height: 100vh; \n"
        "  background-color: #e0d9c7; \n"
        "  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3); \n"
        "}\n"
        "\n"
        "/* Sidebar gauche */\n"
        ".sidebar-left {\n"
        "  width: 200px;\n"
        "  background-color: #c8c0b0; \n"
        "  padding: 20px;\n"
        "  display: flex;\n"
        "  flex-direction: column;\n"
        "  align-items: center;\n"
        "  gap: 15px;\n"
        "  border-right: 1px solid #a0522d; /* Bordure droite pour séparer */\n"
        "  box-shadow: inset -5px 0 10px rgba(0, 0, 0, 0.1); /* Ombre interne pour un effet de page */\n"
        "}\n"
        "\n"
        ".sidebar-left h2 {\n"
        "  font-size: 1.2em; \n"
        "  text-align: center;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "  text-transform: uppercase;\n"
        "}\n"
        "\n"
        "/* Cercle de numéro (adapté au thème) */\n"
        "#number {\n"
        "  width: 80px;\n"
        "  height: 80px;\n"
        "  border-radius: 50%%;\n" /* Notez les %% pour le % littéral */
        "  background-color: #deb887; /* Couleur 'wheat' plus douce */\n"
        "  color: #2a2a2a; /* Texte foncé pour le contraste */\n"
        "  font-size: 28px;\n" /* Taille un peu plus grande */
        "  font-weight: bold;\n"
        "  display: flex;\n"
        "  align-items: center;\n"
        "  justify-content: center;\n"
        "  border: 3px solid #8b4513; /* Bordure marron cohérente */\n"
        "  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); /* Ombre pour la profondeur */\n"
        "}\n"
        "\n"
        "/* Bouton (adapté au thème) */\n"
        "button {\n"
        "  padding: 12px 20px; /* Plus de padding pour un bouton plus grand */\n"
        "  font-size: 1em;\n"
        "  background-color: #8b4513; /* Couleur de bouton cohérente avec l'index */\n"
        "  color: #ffffff;\n"
        "  border: none;\n"
        "  border-radius: 5px; /* Coins légèrement arrondis */\n"
        "  cursor: pointer;\n"
        "  transition: background-color 0.3s ease, transform 0.2s ease;\n"
        "  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Ombre pour le relief */\n"
        "}\n"
        "\n"
        "button:hover {\n"
        "  background-color: #a0522d;\n"
        "  transform: translateY(-2px); /* Léger soulèvement au survol */\n"
        "  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);\n"
        "}\n"
        "\n"
        "button:active {\n"
        "  transform: translateY(0);\n"
        "  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n"
        "}\n"
        "\n"
        "/* Zone principale */\n"
        ".main {\n"
        "  flex-grow: 1;\n"
        "  display: flex;\n"
        "  flex-direction: column;\n"
        "  padding: 20px;\n"
        "  background-color: #fcf9f2; /* Fond très clair pour le contenu principal */\n"
        "  border-bottom: 1px solid #dcd3be; /* Ligne de séparation */\n"
        "  border-right: 1px solid #dcd3be;\n"
        "}\n"
        "\n"
        ".main-header {\n"
        "  font-size: 1.8em;\n"
        "  margin-bottom: 20px;\n"
        "  text-align: center;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "  text-transform: uppercase;\n"
        "  padding-bottom: 10px;\n"
        "  border-bottom: 1px solid #dcd3be; /* Ligne de séparation */\n"
        "}\n"
        "\n"
        "iframe {\n"
        "  flex-grow: 1;\n"
        "  width: 100%%;\n" /* Notez les %% pour le % littéral */
        "  border: none;\n"
        "  background-color: #f4f4e9; /* Même couleur que le corps principal, pour la continuité */\n"
        "  box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.05); /* Légère ombre interne pour l'effet de feuille */\n"
        "  padding: 10px;\n"
        "  box-sizing: border-box; /* Inclure le padding dans la largeur/hauteur */\n"
        "}\n"
        "\n"
        "/* Sidebar droite */\n"
        ".sidebar-right {\n"
        "  width: 200px;\n"
        "  background-color: #c8c0b0; /* Teinte plus claire de parchemin pour les barres latérales */\n"
        "  padding: 20px;\n"
        "  border-left: 1px solid #a0522d; /* Bordure gauche pour séparer */\n"
        "  box-shadow: inset 5px 0 10px rgba(0, 0, 0, 0.1); /* Ombre interne pour un effet de page */\n"
        "}\n"
        "\n"
        ".sidebar-right h2 {\n"
        "  font-size: 1.2em;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "  text-transform: uppercase;\n"
        "}\n"
        "\n"
        ".sidebar-right ul {\n"
        "  list-style: disc inside; /* Points de liste */\n"
        "  padding: 0;\n"
        "  font-size: 0.95em;\n"
        "  color: #333;\n"
        "}\n"
        "\n"
        "h1 {\n" /* Pour le h1 dans le iframe si utilisé */
        "  text-align: center;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "}\n";

    fputs(css, f);
    fclose(f);
}

void generate_dom_js() {
    FILE *f = fopen("ressources/dom.js", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *js =
        "// Ajoute une entrée dans la section récap\n"
        "function addToRecap(text) {\n"
        "  const recapList = document.getElementById(\"recap-list\");\n"
        "  const item = document.createElement(\"li\");\n"
        "  item.textContent = text;\n"
        "  recapList.prepend(item);\n"
        "}\n"
        "\n"
        "// Fonction appelée par le bouton\n"
        "function pickNumber() {\n"
        "  const number = Math.floor(Math.random() * 10);\n"
        "  document.getElementById(\"number\").textContent = number;\n"
        "  addToRecap(`Nombre : ${number}`);\n"
        "}\n"
        "\n"
        "// Écoute des messages venant de l’iframe\n"
        "window.addEventListener(\"message\", (event) => {\n"
        "  if (event.data && event.data.type === \"sectionClick\") {\n"
        "    addToRecap(`Section : ${event.data.label}`);\n"
        "  }\n"
        "});\n";

    fputs(js, f);
    fclose(f);
}
