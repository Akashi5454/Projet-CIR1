#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef CREATEFOLDER_H
#define CREATEFOLDER_H

void creer_dossier_selon_os(void);
void deplacer_fichier_vers_ressources();

#endif
