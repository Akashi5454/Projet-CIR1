#include "createFile.h"

char* replace_links_only(const char* input) {
    static char output[2048];
    output[0] = '\0';

    const char* p = input;

    while (*p) {
        const char* start = strstr(p, "<a>");
        if (!start) {
            strcat(output, p);
            break;
        }

        // Copier tout ce qu'il y a avant <a>
        strncat(output, p, start - p);

        const char* end = strstr(start, "</a>");
        if (!end) {
            strcat(output, start);
            break;
        }

        // Contenu entre <a> et </a>
        char inner[256];
        int len = end - (start + 3);
        strncpy(inner, start + 3, len);
        inner[len] = '\0';

        // Cherche le premier nombre dans inner
        int number = 0;
        for (int i = 0; inner[i]; i++) {
            if (inner[i] >= '0' && inner[i] <= '9') {
                number = atoi(&inner[i]);
                break;
            }
        }

        char link[512];
        if (number > 0)
            sprintf(link, "<a href=\"sect%d.html\">%s</a>", number, inner);
        else
            sprintf(link, "<a>%s</a>", inner);

        strcat(output, link);
        p = end + 4; // après </a>
    }

    return output;
}

FILE* start_section(int section_number) {
    char filename[256];
    sprintf(filename, "export/sect%d.html", section_number);

    FILE* f = fopen(filename, "w");
    if (!f) {
        fprintf(stderr, "Impossible de créer le fichier <%s>\n", filename);
        exit(EXIT_FAILURE);
    }

    fprintf(f, "<!DOCTYPE html>\n<html>\n<head><meta charset=\"UTF-8\"><title>Section %d</title></head>\n<body>\n", section_number);
    fprintf(f, "<h1>Section %d</h1>\n", section_number);
    return f;
}

void end_section(FILE* file) {
    if (file) {
        fprintf(file, "</body>\n</html>\n");
        fclose(file);
    }
}
