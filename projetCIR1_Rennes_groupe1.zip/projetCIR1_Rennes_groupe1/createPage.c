#include "createPage.h"

void generer_la_page_index() {
    FILE *fichier = fopen("index.html", "w");
    if (fichier == NULL) {
        perror("Erreur lors de la création du fichier HTML");
        return;
    }

    fprintf(fichier,
        "<!DOCTYPE html>\n"
        "<html lang=\"fr\">\n"
        "<head>\n"
        "  <meta charset=\"UTF-8\">\n"
        "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
        "  <title>Loup Solitaire - Le Début de l'Aventure</title>\n"
        "  <style>\n"
        "    body {\n"
        "      font-family: 'Georgia', serif;\n"
        "      background-color: #f4f4e9;\n"
        "      color: #333;\n"
        "      margin: 0;\n"
        "      display: flex;\n"
        "      flex-direction: column;\n"
        "      justify-content: center;\n"
        "      align-items: center;\n"
        "      min-height: 100vh;\n"
        "      padding: 20px;\n"
        "      box-sizing: border-box;\n"
        "    }\n"
        "    h1 {\n"
        "      color: #2a2a2a;\n"
        "      font-size: 3.5em;\n"
        "      text-align: center;\n"
        "      margin-bottom: 30px;\n"
        "      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);\n"
        "      letter-spacing: 2px;\n"
        "      text-transform: uppercase;\n"
        "    }\n"
        "    img {\n"
        "      max-width: 90%%;\n"
        "      height: auto;\n"
        "      border: 5px solid #a0522d;\n"
        "      border-radius: 8px;\n"
        "      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);\n"
        "      margin-bottom: 40px;\n"
        "      transition: transform 0.3s ease-in-out;\n"
        "    }\n"
        "    img:hover {\n"
        "      transform: scale(1.02);\n"
        "    }\n"
        "    a {\n"
        "      display: inline-block;\n"
        "      background-color: #8b4513;\n"
        "      color: #ffffff;\n"
        "      padding: 15px 30px;\n"
        "      text-decoration: none;\n"
        "      border-radius: 50px;\n"
        "      font-size: 1.5em;\n"
        "      font-weight: bold;\n"
        "      transition: background-color 0.3s ease, transform 0.3s ease;\n"
        "      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n"
        "      letter-spacing: 1px;\n"
        "      text-transform: uppercase;\n"
        "    }\n"
        "    a:hover {\n"
        "      background-color: #a0522d;\n"
        "      transform: translateY(-3px);\n"
        "      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);\n"
        "    }\n"
        "    a:active {\n"
        "      transform: translateY(0);\n"
        "      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n"
        "    }\n"
        "    @media (max-width: 768px) {\n"
        "      h1 { font-size: 2.5em; }\n"
        "      a { font-size: 1.2em; padding: 12px 25px; }\n"
        "    }\n"
        "    @media (max-width: 480px) {\n"
        "      h1 { font-size: 2em; }\n"
        "      img { border-width: 3px; }\n"
        "      a { font-size: 1em; padding: 10px 20px; }\n"
        "    }\n"
        "  </style>\n"
        "</head>\n"
        "<body>\n"
        "  <h1>Loup Solitaire</h1>\n"
        "  <img src=\"https://media.pocketgamer.fr/images/news/2011/08/Lone-Wolf.png\" alt=\"Illustration Loup Solitaire\" />\n"
        "  <a href=\"export/sect000.html\">Commencer l'Aventure</a>\n"
        "</body>\n"
        "</html>\n"
    );
    printf("✅ index.html generated successfully\n");

    fclose(fichier);
}


void generate_sect000_html() {
    FILE *f = fopen("export/sect000.html", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *html =
        "<!DOCTYPE html>\n"
        "<html lang=\"fr\">\n"
        "<head>\n"
        "  <meta charset=\"UTF-8\" />\n"
        "  <title>Aventure interactive</title>\n"
        "  <link rel=\"stylesheet\" href=\"../ressources/style.css\" />\n"  // ../ pour remonter au bon dossier\n
        "</head>\n"
        "<body>\n" //page divisée en 3 parties
        "  <div class=\"container\">\n"
        "    <!-- Colonne gauche -->\n" //générateur de nombres aléatoires
        "    <div class=\"sidebar-left\">\n"
        "      <h2>Random number picker</h2>\n"
        "      <div id=\"number\">?</div>\n"
        "      <button onclick=\"pickNumber()\">Pick Number</button>\n"
        "    </div>\n"
        "\n"
        "    <!-- Zone centrale -->\n" //iframe
        "    <div class=\"main\">\n"
        "      <div class=\"main-header\"></div>\n"
        "      <iframe id=\"viewer\" src=\"sect1.html\"></iframe>\n"
        "    </div>\n"
        "\n"
        "    <!-- Colonne droite -->\n" //historique
        "    <div class=\"sidebar-right\">\n"
        "      <h2>History</h2>\n"
        "      <ul id=\"recap-list\"></ul>\n"
        "    </div>\n"
        "  </div>\n"
        "\n"
        "  <script src=\"../ressources/dom.js\"></script>\n"
        "</body>\n"
        "</html>\n";

    fputs(html, f);
    printf("✅ sect000.htmlm generated successfully\n");
    fclose(f);
}

void generate_inventory_page() {
    FILE *file = fopen("export/inventory.html", "w");
    if (!file) {
        perror("Erreur : impossible de créer inventory.html");
        return;
    }

    fprintf(file,
        "<!DOCTYPE html>\n"
        "<html lang=\"en\">\n"
        "<head>\n"
        "  <meta charset=\"UTF-8\">\n"
        "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
        "  <title>Adventure Sheet</title>\n"
        "  <style>\n" //ajout du css directement dans le code html
        "    body { font-family: Arial, sans-serif; padding: 20px; background: #f4f4f4; }\n"
        "    h1, h2 { color: #222; }\n"
        "    .section { margin-bottom: 30px; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 0 5px rgba(0,0,0,0.1); }\n"
        "    label { display: block; margin-top: 10px; font-weight: bold; }\n"
        "    input[readonly], select:disabled { background-color: #eee; border: 1px solid #ccc; }\n"
        "    button { margin-top: 5px; }\n"
        "    #notes {\n"
        "      white-space: pre-wrap;\n"
        "      min-height: 80px;\n"
        "      padding: 8px;\n"
        "      background-color: #eee;\n"
        "      border: 1px solid #ccc;\n"
        "      border-radius: 4px;\n"
        "      color: #333;\n"
        "    }\n"
        "    #inventory {\n"
        "      list-style-type: disc;\n"
        "      padding-left: 20px;\n"
        "    }\n"
        "    .stat-buttons button { margin-right: 5px; }\n"
        "  </style>\n"
        "</head>\n"
        "<body>\n"

        "  <h1>🧙 Adventure Sheet - Book 2 (Read Only)</h1>\n"

        "  <div class=\"section\">\n"
        "    <h2>🎯 Basic Stats</h2>\n"
        "    <label for=\"combatSkill\">Combat Skill</label>\n"
        "    <input type=\"number\" id=\"combatSkill\" readonly>\n"
        "    <div class=\"stat-buttons\">\n"
        "      <button onclick=\"adjustStat('combatSkill', -1)\">-1</button>\n"
        "      <button onclick=\"adjustStat('combatSkill', 1)\">+1</button>\n"
        "    </div>\n"
        "    <label for=\"endurance\">Endurance</label>\n"
        "    <input type=\"number\" id=\"endurance\" readonly>\n"
        "    <div class=\"stat-buttons\">\n"
        "      <button onclick=\"adjustStat('endurance', -1)\">-1</button>\n"
        "      <button onclick=\"adjustStat('endurance', 1)\">+1</button>\n"
        "    </div>\n"
        "    <button onclick=\"generateStats()\">🎲 Roll Stats</button>\n"
        "  </div>\n"

        "  <div class=\"section\">\n"
        "    <h2>🛡 Available Kai Disciplines</h2>\n"
        "    <p>💡 Starting Book 2, you gain one extra Kai Discipline (total: 6).</p>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Survival</label>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Healing</label>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Mind Over Matter</label>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Mindblast</label>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Mindshield</label>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Weaponskill</label>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Animal Kinship</label>\n"
        "    <label><input type=\"checkbox\" onchange=\"limitCheckboxes(this)\"> Sixth Sense / Camouflage</label>\n"
        "    <p>🔢 Maximum of 6 disciplines allowed.</p>\n"
        "  </div>\n"

        "  <div class=\"section\">\n"
        "    <h2>💰 Gold</h2>\n"
        "    <input type=\"number\" id=\"gold\" readonly>\n"
        "    <button onclick=\"generateGold()\">🎲 Roll Gold</button>\n"
        "    <p>💡 Initial draw of Gold Crowns (max 50).</p>\n"
        "  </div>\n"

        "  <div class=\"section\">\n"
        "    <h2>🎒 Inventory</h2>\n"
        "    <ul id=\"inventory\"></ul>\n"
        "    <input type=\"text\" id=\"newItem\" placeholder=\"New item\">\n"
        "    <button onclick=\"addItem()\">➕ Add</button>\n"
        "    <button onclick=\"removeLastItem()\">➖ Remove Last</button>\n"
        "    <p>🧳 Maximum capacity: 8 items + weapons + coins.</p>\n"
        "  </div>\n"

        "  <div class=\"section\">\n"
        "    <h2>📈 Progression Rules</h2>\n"
        "    <p>• Your decisions affect future gains (strength, intelligence, dexterity...)</p>\n"
        "    <p>• Disciplines and items are carried over to the next books.</p>\n"
        "  </div>\n"

        "  <script src=\"../ressources/dom.js\"></script>\n"
        "</body>\n"
        "</html>\n"
    );

    fclose(file);
    printf("✅ inventory.html generated successfully\n");
}


void generate_style_css() {
    FILE *f = fopen("ressources/style.css", "w");
    if (!f) {
        perror("Erreur ouverture fichier");
        return;
    }

    const char *css =
       "/* Styles généraux pour le corps et le conteneur principal */\n"
        "body {\n"
        "  margin: 0;\n"
        "  font-family: 'Georgia', serif; \n"
        "  background-color: #f4f4e9;\n"
        "  color: #333; \n"
        "  line-height: 1.6; /* Améliore la lisibilité */\n"
        "}\n"
        "\n"
        ".container {\n"
        "  display: flex;\n"
        "  min-height: 100vh; \n"
        "  background-color: #e0d9c7; \n"
        "  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3); \n"
        "}\n"
        "\n"
        "/* Sidebar gauche */\n"
        ".sidebar-left {\n"
        "  width: 200px;\n"
        "  background-color: #c8c0b0; \n"
        "  padding: 20px;\n"
        "  display: flex;\n"
        "  flex-direction: column;\n"
        "  align-items: center;\n"
        "  gap: 15px;\n"
        "  border-right: 1px solid #a0522d; /* Bordure droite pour séparer */\n"
        "  box-shadow: inset -5px 0 10px rgba(0, 0, 0, 0.1); /* Ombre interne pour un effet de page */\n"
        "}\n"
        "\n"
        ".sidebar-left h2 {\n"
        "  font-size: 1.2em; /* Taille de police légèrement plus grande */\n"
        "  text-align: center;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "  text-transform: uppercase;\n"
        "}\n"
        "\n"
        "/* Cercle de numéro (adapté au thème) */\n"
        "#number {\n"
        "  width: 80px;\n"
        "  height: 80px;\n"
        "  border-radius: 50%%;\n"
        "  background-color: #deb887; /* Couleur 'wheat' plus douce */\n"
        "  color: #2a2a2a; /* Texte foncé pour le contraste */\n"
        "  font-size: 28px;\n"
        "  font-weight: bold;\n"
        "  display: flex;\n"
        "  align-items: center;\n"
        "  justify-content: center;\n"
        "  border: 3px solid #8b4513; /* Bordure marron cohérente */\n"
        "  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); /* Ombre pour la profondeur */\n"
        "}\n"
        "\n"
        "/* Bouton (adapté au thème) */\n"
        "button {\n"
        "  padding: 12px 20px; /* Plus de padding pour un bouton plus grand */\n"
        "  font-size: 1em;\n"
        "  background-color: #8b4513; /* Couleur de bouton cohérente avec l'index */\n"
        "  color: #ffffff;\n"
        "  border: none;\n"
        "  border-radius: 5px; /* Coins légèrement arrondis */\n"
        "  cursor: pointer;\n"
        "  transition: background-color 0.3s ease, transform 0.2s ease;\n"
        "  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Ombre pour le relief */\n"
        "}\n"
        "\n"
        "button:hover {\n"
        "  background-color: #a0522d;\n"
        "  transform: translateY(-2px); /* Léger soulèvement au survol */\n"
        "  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);\n"
        "}\n"
        "\n"
        "button:active {\n"
        "  transform: translateY(0);\n"
        "  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n"
        "}\n"
        "\n"
        "/* Zone principale */\n"
        ".main {\n"
        "  flex-grow: 1;\n"
        "  display: flex;\n"
        "  flex-direction: column;\n"
        "  padding: 20px;\n"
        "  background-color: #fcf9f2; /* Fond très clair pour le contenu principal */\n"
        "  border-left: 1px solid #dcd3be; /* Bordure subtile pour le contenu */\n"
        "  border-right: 1px solid #dcd3be;\n"
        "}\n"
        "\n"
        ".main-header {\n"
        "  font-size: 1.8em;\n"
        "  margin-bottom: 20px;\n"
        "  text-align: center;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "  text-transform: uppercase;\n"
        "  padding-bottom: 10px;\n"
        "  border-bottom: 1px solid #dcd3be; /* Ligne de séparation */\n"
        "}\n"
        "\n"
        "iframe {\n"
        "  flex-grow: 1;\n"
        "  width: 100%%;\n" /* Notez les %% pour le % littéral */
        "  border: none;\n"
        "  background-color: #f4f4e9; /* Même couleur que le corps principal, pour la continuité */\n"
        "  box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.05); /* Légère ombre interne pour l'effet de feuille */\n"
        "  padding: 10px;\n"
        "  box-sizing: border-box; /* Inclure le padding dans la largeur/hauteur */\n"
        "}\n"
        "\n"
        "/* Sidebar droite */\n"
        ".sidebar-right {\n"
        "  width: 200px;\n"
        "  background-color: #c8c0b0; /* Teinte plus claire de parchemin pour les barres latérales */\n"
        "  padding: 20px;\n"
        "  border-left: 1px solid #a0522d; /* Bordure gauche pour séparer */\n"
        "  box-shadow: inset 5px 0 10px rgba(0, 0, 0, 0.1); /* Ombre interne pour un effet de page */\n"
        "}\n"
        "\n"
        ".sidebar-right h2 {\n"
        "  font-size: 1.2em;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "  text-transform: uppercase;\n"
        "}\n"
        "\n"
        ".sidebar-right ul {\n"
        "  list-style: disc inside; /* Points de liste */\n"
        "  padding: 0;\n"
        "  font-size: 0.95em;\n"
        "  color: #333;\n"
        "}\n"
        "\n"
        "h1 {\n"
        "  text-align: center;\n"
        "  color: #2a2a2a;\n"
        "  font-family: 'Times New Roman', serif;\n"
        "}\n";

    fputs(css, f);
    printf("✅ style.css generated successfully\n");
    fclose(f);
}

void generate_dom_js() {
    FILE *file = fopen("ressources/dom.js", "w");
    if (!file) {
        perror("Erreur : impossible de créer dom.js");
        return;
    }

    fprintf(file,
        "function generateStats() {\n" //fonction pour generer les stats pour Combat skill et endurance
        "  const combatSkill = Math.floor(Math.random() * 10) + 10;\n"
        "  const endurance = Math.floor(Math.random() * 10) + 20;\n"
        "  document.getElementById('combatSkill').value = combatSkill;\n"
        "  document.getElementById('endurance').value = endurance;\n"
        "}\n\n"

        "function adjustStat(statId, delta) {\n"  //fonction qui ajoute ou enlève 1 a combat skill
        "  const input = document.getElementById(statId);\n"
        "  let value = parseInt(input.value) || 0;\n"
        "  value += delta;\n"
        "  input.value = value;\n"
        "}\n\n"

        "function generateGold() {\n"  //fonction pour generer le nombre de gold de depart
        "  const gold = (Math.floor(Math.random() * 10) + 1) * 5;\n"
        "  document.getElementById('gold').value = gold;\n"
        "}\n\n"

        "function addItem() {\n"   //ajouter un item
        "  const itemInput = document.getElementById('newItem');\n"
        "  const itemText = itemInput.value.trim();\n"
        "  if (itemText === '') return;\n"
        "  const list = document.getElementById('inventory');\n"
        "  const items = list.getElementsByTagName('li');\n"
        "  if (items.length >= 8) {\n"
        "    alert('🛑 Inventory full (8 items max)');\n"
        "    return;\n"
        "  }\n"
        "  const li = document.createElement('li');\n"
        "  li.textContent = itemText;\n"
        "  list.appendChild(li);\n"
        "  itemInput.value = '';\n"
        "}\n\n"

        "function removeLastItem() {\n"  //enlever le dernier item ajouter
        "  const list = document.getElementById('inventory');\n"
        "  if (list.lastChild) {\n"
        "    list.removeChild(list.lastChild);\n"
        "  }\n"
        "}\n\n"

        "function limitCheckboxes(checkbox) {\n"    //ajoute une limite de 6 cases cochees
        "  const checkboxes = document.querySelectorAll('input[type=\"checkbox\"]');\n"
        "  const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;\n"
        "  if (checkedCount > 6) {\n"
        "    checkbox.checked = false;\n"
        "    alert('🛑 You may only select 6 disciplines.');\n"
        "  }\n"
        "}\n\n"

        "// Ajoute une entrée dans la section récap\n"
        "function addToRecap(text) {\n"
        "  const recapList = document.getElementById(\"recap-list\");\n"
        "  const item = document.createElement(\"li\");\n"
        "  item.textContent = text;\n"
        "  recapList.prepend(item);\n"
        "}\n\n"

        "// Fonction appelée par le bouton\n"
        "function pickNumber() {\n"
        "  const number = Math.floor(Math.random() * 10);\n"
        "  document.getElementById(\"number\").textContent = number;\n"
        "  addToRecap(`Nombre : ${number}`);\n"
        "}\n\n"

        "// Écoute des messages venant de l’iframe\n"
        "window.addEventListener(\"message\", (event) => {\n"
        "  if (event.data && event.data.type === \"sectionClick\") {\n"
        "    addToRecap(`Section : ${event.data.label}`);\n"
        "  }\n"
        "});\n"
    );

    fclose(file);
    printf("✅ dom.js generated successfully\n");
}
