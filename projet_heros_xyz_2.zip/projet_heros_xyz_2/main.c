#include "createFile.h"


int main() {
    const char* filename = "/Users/noegavard/Documents/ISEN 2024 - 2025/projet algoC/projet_heros_xyz_2/ressources/02fotw.data";
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        perror("Erreur d'ouverture du fichier");
        fprintf(stderr, "Chemin essayé : %s\n", filename);
        exit(EXIT_FAILURE);
    }

    char line[LINE_SIZE];
    FILE* current_section = NULL;
    int section_count = 0;

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0;  // Supprime le saut de ligne

        if (strncmp(line, "<section>", 9) == 0) {
            printf("Début d'une nouvelle section (num %d)\n", section_count + 1);

            if (current_section != NULL)
                end_section(current_section);

            section_count++;
            if (section_count > 350) {
                fprintf(stderr, "Erreur : plus de 350 sections détectées.\n");
                exit(EXIT_FAILURE);
            }

            current_section = start_section(section_count);

        } else if (strncmp(line, "</section>", 10) == 0) {
            printf("Fin de la section actuelle\n");
            end_section(current_section);
            current_section = NULL;

        } else if (current_section != NULL) {
            process_choice(line, current_section);
        }
    }

    if (current_section != NULL)
        end_section(current_section);

    fclose(file);
    return 0;
}
