// Ajoute une entrée dans la section récap
function addToRecap(text) {
  const recapList = document.getElementById("recap-list");
  const item = document.createElement("li");
  item.textContent = text;
  recapList.prepend(item);
}

// Fonction appelée par le bouton
function pickNumber() {
  const number = Math.floor(Math.random() * 10);
  document.getElementById("number").textContent = number;
  addToRecap(`Nombre : ${number}`);
}

// Écoute des messages venant de l’iframe
window.addEventListener("message", (event) => {
  if (event.data && event.data.type === "sectionClick") {
    addToRecap(`Section : ${event.data.label}`);
  }
});
