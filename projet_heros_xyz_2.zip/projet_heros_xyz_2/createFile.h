#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef CREFICHIERBASE_H
#define CREFICHIERBASE_H

#define LINE_SIZE 2000

FILE* start_section(int section_number);
void end_section(FILE* file);
char* replace_links_only(const char* input);

#endif
